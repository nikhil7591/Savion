def send_notification(user_id: str, message: str):
    # TODO: Integrate with email, SMS, push, or websocket
    print(f"Notify {user_id}: {message}")

def send_alert(user_id: str, message: str):
    # TODO: Integrate with alarm/alert system
    print(f"ALERT for {user_id}: {message}")