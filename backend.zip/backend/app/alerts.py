def check_negative_balance(balance):
    return balance < 0